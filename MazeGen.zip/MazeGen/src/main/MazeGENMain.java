package main;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

public class MazeGENMain {
	public static void main(String[]args){
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);

		frame.pack();
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		Gameloop mainThread = new Gameloop(frame);
		
		mainThread.start();
	}

}

class Gameloop extends Thread{
	private volatile static JFrame frame;
	
	public Gameloop(JFrame frame){
		this.frame = frame;
	}
	
	//static int[][]map = Build.map(20, 20);
	static int[][]map = new int[181][111];
	
	public void run(){
		frame.setContentPane(new JPanel(){
			public void paintComponent(Graphics g){
				for(int i = 0; i < map.length; i++){
					for(int j = 0; j < map[i].length; j++){
						if(map[i][j] == 0){
							g.setColor(Color.black);
						}else{
							g.setColor(new Color(map[i][j],map[i][j],map[i][j]));
						}
						g.fillRect(i*8, j*8, 8, 8);
					}
				}
				
			}
		});
		frame.setVisible(true);
		
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map[i].length; j++){
				if((i/2)*2 != i && (j/2)*2 != j){
					map[i][j] = 255;
				}
			}
		}
		
		map[1][1] = 200;
		
		int mod = 255;
		
		int count = 0;
		
		int col = 0;
		
		boolean toDo = true;
		ArrayList<Integer> xWorm = new ArrayList<Integer>(), yWorm = new ArrayList<Integer>();
		xWorm.add(0,1);
		yWorm.add(0,1);
		
		while(true){			
			
			if(toDo){
				toDo = check(map);
				int index = 0;
				
				ArrayList<Integer>xpath = new ArrayList<Integer>();
				ArrayList<Integer>ypath = new ArrayList<Integer>();
		
				for(int i = 0; i < map.length; i++){
					for(int j = 0; j < map[i].length; j++){
						if(map[i][j] != 200 && (checkNeighbor(map, i-2, j) || checkNeighbor(map, i+2, j) || checkNeighbor(map, i, j-2) || checkNeighbor(map, i, j+2))){
							xpath.add(index, i);
							ypath.add(index, j);
							index++;
						}
					}
				}
				
				index = (int)(Math.random()*(xpath.size()/2)*2);
				
				switch((int)(Math.random()*4+1)){
				case 1:
					try{
						if(checkNeighbor(map, xpath.get(index)-2, ypath.get(index))){
							map[xpath.get(index)-1][ypath.get(index)] = 180;
							map[xpath.get(index)][ypath.get(index)] = 200;
						}
					}catch(Exception e){}
					break;
				case 2:
					try{
						if(checkNeighbor(map, xpath.get(index)+2, ypath.get(index))){
							map[xpath.get(index)+1][ypath.get(index)] = 180;
							map[xpath.get(index)][ypath.get(index)] = 200;
						}
					}catch(Exception e){}
					break;
				case 3:
					try{
						if(checkNeighbor(map, xpath.get(index), ypath.get(index)-2)){
							map[xpath.get(index)][ypath.get(index)-1] = 180;
							map[xpath.get(index)][ypath.get(index)] = 200;
						}
					}catch(Exception e){}
					break;
				case 4:
					try{
						if(checkNeighbor(map, xpath.get(index), ypath.get(index)+2)){
							map[xpath.get(index)][ypath.get(index)+1] = 180;
							map[xpath.get(index)][ypath.get(index)] = 200;
						}
					}catch(Exception e){}
					break;
				}
			}else if(count < 3){
				
				
				for(int i = 0; i < xWorm.size(); i++){
					map[xWorm.get(i)][yWorm.get(i)] = mod;
				}
				int buf = xWorm.size();
				for(int i = 0; i < buf; i++){
					boolean c = false;
					int lastX = xWorm.get(i), lastY = yWorm.get(i);
					try{
						if(map[lastX-1][lastY] != mod && map[lastX-1][lastY] != 0){
							xWorm.set(i, lastX-1);
							c = true;
						}
					}catch(Exception e){}
					try{
						if(map[lastX+1][lastY] != mod && map[lastX+1][lastY] != 0){
							if(!c){
								xWorm.set(i, lastX+1);
							}else{
								xWorm.add(lastX+1);
								yWorm.add(lastY);
							}
							c = true;
						}
					}catch(Exception e){}
					try{
						if(map[lastX][lastY-1] != mod && map[lastX][lastY-1] != 0){
							if(!c){
								yWorm.set(i, lastY-1);
							}else{
								xWorm.add(lastX);
								yWorm.add(lastY-1);
							}
							c = true;
						}
					}catch(Exception e){}
					try{
						if(map[lastX][lastY+1] != mod && map[lastX][lastY+1] != 0){
							if(!c){
								yWorm.set(i, lastY+1);
							}else{
								xWorm.add(lastX);
								yWorm.add(lastY+1);
							}
						}
					}catch(Exception e){}
					
				}
				
				if(allMod(map, mod)){
					mod = (int)(Math.random()*255+1);
					
					xWorm.clear();
					yWorm.clear();
					
					xWorm.add(1);
					yWorm.add(1);
					for(int i = 0; i < count; i++){
						int trans = (int)(Math.random()*map.length);
						int trans2 = (int)(Math.random()*map[trans].length);
						if(map[trans][trans2] != 0){
							xWorm.add(trans);
							yWorm.add(trans2);
						}
					}
					count++;
				}
				
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				
				
			}else{
				if(col < map[0].length){
					for(int row = 0; row < map.length; row++){
						if((col/2)*2 != col && (row/2)*2 != row){ 
							map[row][col] = 255;
						}else{
							map[row][col] = 0;
						}
					}
					
					col++;
				}else{
					col = 0;
					toDo = true;
					map[1][1] = 200;
					count = 0;
				}
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			frame.setTitle(String.valueOf(count));
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			frame.repaint();
		}
		
	}
	
	private static boolean checkNeighbor(int[][]map, int i, int j){
		try{
			if(map[i][j] == 200){
				return true;
			}
		}catch(Exception e){}
		return false;
	}
	private static boolean check(int[][]map){
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map[i].length; j++){
				if(map[i][j] == 255){
					return true;
				}
			}
		}
		return false;
	}
	private static boolean allMod(int[][]map, int mod){
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map[i].length; j++){
				if(map[i][j] != mod && map[i][j] != 0){
					return false;
				}
			}
		}
		return true;
	}
	
}
