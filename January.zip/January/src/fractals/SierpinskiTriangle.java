package fractals;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;

public class SierpinskiTriangle extends Thread{
	
	static JFrame frame;
	
	Triangle triangle;
	
	public static int xSet;

	public static int ySet;
	
	public int sx, sy;
	
	public void run(){
		
		triangle = new Triangle(frame.getWidth()/2, frame.getHeight()/2);
		triangle.start(50);
		
		render();
		render();
		boolean b = false;
		while(true){
			
			render();
			update();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void update(){
		triangle.extend();
	}
	private void render(){
		BufferStrategy bs = frame.getBufferStrategy();
		
		if(bs == null){
			frame.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		/////////////////////////////////////////////////
		
		g.setColor(Color.black);
		g.fillRect(0, 0, frame.getWidth(), frame.getHeight());
		
		g.setColor(Color.red);
		
		triangle.draw(g);
		
		//////////////////////////////////////////////////
		
		g.dispose();
		bs.show();
	}
	
	public static void main(String[] args){
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		frame.setVisible(true);
		
		SierpinskiTriangle triangle = new SierpinskiTriangle();
		triangle.start();
	}

}
class Triangle{
	
	
	Triangle[] extensions;
	
	int cx, cy;
	
	private int x,x2,x3,y,y2,y3;
	
	public Triangle(int cx, int cy){
		this.cx = cx;
		this.cy = cy;
	}
	
	public void start(int length){
		int xOffset = (int)(((Math.sin(30)*(Math.sqrt(Math.pow(length, 2)*2)/Math.sin(120)))/Math.sqrt(3))*2);

		x = cx; y = cy - length;
		x2 = cx + xOffset; y2 = cy + length-xOffset;
		x3 = cx - xOffset; y3 = cy + length-xOffset;
	}
	public void extend(){
		if(extensions == null){
			extensions = new Triangle[3];
			
			int length = (cy - y)/2;
			int xOffset = (int)(((Math.sin(30)*(Math.sqrt(Math.pow(length, 2)*2)/Math.sin(120)))/Math.sqrt(3))*2);
			int yOffset = length - xOffset;
			extensions[0] = new Triangle(cx, cy - length);
			extensions[0].start(length);
			extensions[1] = new Triangle(cx + xOffset, cy + yOffset);
			extensions[1].start(length);
			extensions[2] = new Triangle(cx - xOffset, cy + yOffset);
			extensions[2].start(length);
		}else{
			extensions[0].extend();
			extensions[1].extend();
			extensions[2].extend();
		}
	}
	
	public void draw(Graphics g){
		g.drawLine(x+SierpinskiTriangle.xSet, y+SierpinskiTriangle.ySet, x2+SierpinskiTriangle.xSet, y2+SierpinskiTriangle.ySet);
		g.drawLine(x2+SierpinskiTriangle.xSet, y2+SierpinskiTriangle.ySet, x3+SierpinskiTriangle.xSet, y3+SierpinskiTriangle.ySet);
		g.drawLine(x+SierpinskiTriangle.xSet, y+SierpinskiTriangle.ySet, x3+SierpinskiTriangle.xSet, y3+SierpinskiTriangle.ySet);
				
		if(extensions != null){
			for(Triangle i : extensions){
				i.draw(g);
			}
		}


	}
}