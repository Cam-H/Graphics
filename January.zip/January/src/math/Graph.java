package math;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

import javax.swing.JFrame;

public class Graph extends Thread implements ImageObserver{
	
	static JFrame frame;
	
	static double scale = 1;
	
	static boolean toUpdate = true;
	
	public void run(){
		
		render();
		
		while(true){
			
			if(toUpdate){
				render();
				toUpdate = false;
			}
			
			try {
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void render(){
		BufferStrategy bs = frame.getBufferStrategy();
		
		if(bs == null){
			frame.createBufferStrategy(1);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		///////////////////////////////////////////////////////
		
		g.setColor(new Color(255,255,255));
		g.fillRect(0, 0, frame.getWidth(), frame.getHeight());
		
		g.setColor(new Color(0,0,0));
		g.drawString("Scale: "+String.valueOf(scale), 20, 20);
		
		BufferedImage graph = new BufferedImage(frame.getWidth()/2, frame.getHeight()/2, BufferedImage.TYPE_INT_ARGB);
		drawGraph(graph);
		g.drawImage(graph, frame.getWidth()/4, frame.getHeight()/2 - frame.getWidth()/4, frame.getWidth()/2, frame.getWidth()/2, this);
		
		///////////////////////////////////////////////////////
		
		g.dispose();
		bs.show();
	}
	
	private void drawGraph(BufferedImage graph){
		Graphics g = graph.getGraphics();
		
		g.setColor(new Color(0,0,0));
		g.drawLine(graph.getWidth()/2, 0, graph.getWidth()/2, graph.getHeight());
		g.drawLine(0, graph.getHeight()/2, graph.getWidth(), graph.getHeight()/2);
		
		int lastX = -graph.getWidth()/2;
		int lastY = 0;
		
		for(int i = -graph.getWidth()/2; i < graph.getWidth()/2; i++){
			int x = (int)(i * scale);
			int y = (int)(Math.sin(x)*10*scale);
			int length = (int)Math.sqrt(Math.pow(lastX - (i+graph.getWidth()/2-1), 2) + Math.pow((graph.getHeight()/2 - y), 2));
			if(length > 255){
				g.setColor(Color.blue);
			}else if(length > 510){
				g.setColor(Color.red);
			}else{
				g.setColor(Color.green);
			}
			System.out.println(length+" length "+i);
			g.drawLine(lastX, lastY, (i+graph.getWidth()/2-1), (graph.getHeight()/2 - y));
			
			lastX = (i+graph.getWidth()/2-1);
			lastY = (graph.getHeight()/2 - y);
		}
	}
	
//***************************************************************************************************************************************************************
	public static void main(String[] args){
		
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setUndecorated(true);
		
		frame.setVisible(true);
		
		frame.addKeyListener(new keyaction());
		
		Graph loop = new Graph();
		loop.start();
	}
//***************************************************************************************************************************************************************
	
	@Override
	public boolean imageUpdate(Image arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
		return false;
	}

}
class keyaction implements KeyListener{

	@Override
	public void keyPressed(KeyEvent e) {
		System.out.println(e.getKeyCode());
		if(e.getKeyCode() == 38){
			Graph.scale += .1;
		}
		if(e.getKeyCode() == 40){
			Graph.scale -= .1;
		}
		
		Graph.toUpdate = true;
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}