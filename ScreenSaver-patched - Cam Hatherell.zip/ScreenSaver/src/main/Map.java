/*
 * *********************************
 * Map Class
 * 
 * The main loop of the program that handles most graphics stuff
 * 
 * Cam Hatherell
 * March 22 2018
 * *******************************
 */
package main;

import java.awt.Color;
import java.awt.Toolkit;
import java.util.ArrayList;

import hsa2.GraphicsConsole;

public class Map extends Thread{//Begin Map class
	
	private Block[][] map;//The map used to hold the maze generator
	
	private static byte pathCount = 50;//The number of individual paths present in the maze generator
	
	private int display;//The current action being performed by the computer
	
	private ArrayList<Type> paths;//The list of necessary maze gen data
	private ArrayList<Smoke>particles;//The list of necessary smoke data
	private ArrayList<Orb>orbs;//The list of necessary orb data

	private double width = 0;//Width of one block in the maze
	private double height = 0;//Height of one block in the maze
	
	private int passes;//Number of passes left to take (rough) for action 2 and 3
	private int basePasses = 6000;//Base number of passes to take per trip
	
	/*
	 Map Constructor
	 
	 Initializes all relevant data; specifically for the maze generator which is the first action
	 
	 Parameters: None
	 Dependencies: java.util
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Map(){//Begin Map constructor
		
		display = 0;//Sets the display to maze gen to start
		
		map = new Block[161][91];//Map of blocks for the maze generator
		
		for(int i = 0; i < map.length; i++){//Begin for 1
			for(int j = 0; j < map[i].length; j++){//Begin for 2
				if((i/2)*2 != i && (j/2)*2 != j){//If i and j are odd : enter
					map[i][j] = new Block((byte)1);//Sets block to empty type 2
				}else{//Otherwise
					map[i][j] = new Block((byte)0);//Sets block to empty type 1
				}//end if
			}//end for 2
		}//end for 1
		
		paths = new ArrayList<Type>();//Initializes list for paths
		
		begin();//Calls method to fill list for paths
		
		particles = new ArrayList<Smoke>();//Initializes list for smoke particles
		orbs = new ArrayList<Orb>();//Initializes list for orbs

	}//End constructor
	
	/*
	 draw method
	 
	 Handles drawing (in the case of the maze gen) or exporting the drawing to another method
	 
	 Parameters: GraphicsConsole gc
	 Dependencies: none
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public void draw(GraphicsConsole gc){//Begin draw method
		width = (double)gc.getWidth() / map.length;//Gets the necessary width for the blocks
		height = (double)gc.getHeight() / map[0].length;//Gets the necessary height for the blocks
		
		//Runs through map array to draw out blocks
		for(int i = 0; i < map.length; i++){//Begin for 1
			for(int j = 0; j < map[i].length; j++){//Begin for 2
				
				switch(map[i][j].type()){//Begin switch statement
				case 0: case 1://Cases for empty block type
					gc.setColor(new Color(0,0,0));//Black
					break;//Break empty bock type case
				default://Default case
					byte type = map[i][j].type();//Gets the type of the block toDraw
					if(type > paths.size() + 1){//Enters if it runs into the set of duplicate types
						paths.get(type - pathCount - 2).setColor(gc);//Sets the colour based on the original typed
					}else{//otherwise
						paths.get(type - 2).setColor(gc);//Sets the colour based on the type minus the empty cases
					}//End if
				}//End switch statement
				
				gc.fillRect((int)(i*width)-1, (int)(j*height) - 1, (int)width + 2, (int)height + 2);//Draws the block
				
			}//End for 2
		}//End for 1
		
		//Runs through the smoke particle array, calling a method to draw the particles
		for(int i = 0; i < particles.size(); i++){
			particles.get(i).draw(gc);
		}
		
		//Runs through the orbs array, calling a method to draw the prbs separately + recursively
		for(int i = 0; i < orbs.size(); i++){
			orbs.get(i).draw(gc);
		}
	}//End draw method
	
	/*
	 run method
	 
	 The main loop for the program that handles the logic based on the value of display
	 
	 Parameters: non
	 Dependencies: Thread
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public void run(){//Begin run method
		
		//Gets the screen dimensions
		int screenHeight = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		int screenWidth = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		
		while(true){//Runs until user ends the program
			
			switch(display){
			case 0://Maze generator
				
				if(check()){//Checks to see whether one path has taken over | true if so
					
					clearBlocks();//Hides all blocks
					
					display = 1;//Marks to start next action
					
					passes = basePasses;//Resets passes
					
					//Adds a buffer between when this action ends and the next starts
					try {//Begin try
						Thread.sleep(1000);
					} catch (InterruptedException e) {//catch
						e.printStackTrace();
					}//End try-catch
				}//End if
				
				//Runs through the list of paths | Adding blocks to their grouping
				for(byte i = 0; i < paths.size(); i++){
					if(!paths.get(i).delayed()){//Applies the delay class to slow down the grouping
						path((byte)(i + 2));
					}
				}
				
				break;//End maze generator
			case 1://Burning the map

				int x = 0;//Base x value for the spawn of particles
				
				double windPower = 0;//Unused | Can change the x value of Action 2 particles as they move
				
				boolean left = false;//Tells the modifier whether to add or subtract from x
				
				while(passes > 0 || particles.size() > 0){//Runs until enough passes have happened and there are no more particles
					//windPower += Math.random()-.5; -Old code that I decided against using for aesthetic reasons; still functional though
					
					int growth = (int)(Math.random()*6);//Gives a number between 0-5 for how many particles spawn
					
					//Adds growth number of particles so long as passes has not been reduced to 0
					for(int i = 0; i < growth && passes > 0; i++){//Begin for
						particles.add(new Smoke((int)(Math.random()*2), x, screenHeight));
					}//End for
					
					passes -= growth;//Reduces passes by growth
					
					//Calls the method to do the physics for all the particles including dimming and floating
					for(int i = 0; i < particles.size(); i++){
						if(!particles.get(i).doPhysics(windPower)){//Enters if the particle has been marked to die
							particles.remove(i);
							i--;//Goes back an index to account for the lost one
						}//End if
					}//End for
					
					//Allows the spawner to move from side to side on the screen
					if(left){
						if((x -= 2) < 0){
							left = false;
						}
					}else{
						if((x += 2) > screenWidth){
							left = true;
						}
					}
					
					//Sets update rate to 60 times per second
					try {
						Thread.sleep(1000/60);
					} catch (InterruptedException e) {}
				}

				display = 2;//Sets the action to the next step
				
				passes = basePasses;//Resets passes
				
				break;//End map burning
			case 2://Reconstructing the map
				
				//Spawns the first orb
				orbs.add(new Orb(true, (int)(Math.random()*screenWidth), (int)(Math.random()*screenHeight), 0, (int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255)));

				
				while((passes-=5) > 0 || orbs.size() > 0){//Begin while loop	

					int growth = (int)(Math.random()*10);//Gets the chance for spawning

					if(growth > 8 && passes > 0){//20% chance an orb spawns
						//Spawns the orb and sets it to be stationary
						orbs.add(new Orb(true, (int)(Math.random()*screenWidth), (int)(Math.random()*screenHeight), 0, (int)(Math.random() * 255), (int)(Math.random() * 255), (int)(Math.random() * 255)));
						orbs.get(orbs.size() - 1).stop();
					}//End if
					
					//Runs through all the orbs to do the physics for them as well as check their life
					for(int i = 0; i < orbs.size(); i++){
						if(!orbs.get(i).doPhysics()){
							orbs.remove(i);//Kills the orb if they dwindle
							i--;
						}
					}
					//Sets update rate to 60 times per second
					try {
						Thread.sleep(1000/60);
					} catch (InterruptedException e) {}
				}//End while loop

				display = 0;//Sends program back to action 0 to repeat
				
				passes = basePasses;//Resets passes
				
				begin();//Refreshes the paths to be used in action 0
								
				break;//End Map Reconstruction
			}//End switch
			
			//Random sleep
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {}
		}//End while
		
	}//End run method
	
	/*
	 path method
	 
	 Finds possible routes for every path and executes segments of them for the maze gen
	 
	 Parameters: byte toCheck
	 Dependencies: none
	 
	 Cam Hatherell
	 March 22 2018
	 */
	private void path(byte toCheck){//Begin path method
		
		ArrayList<Point>options = new ArrayList<Point>();//New list to hold possible routes
		
		int index = 0;//chooses which route to take later on
		
		//Runs through the entire map looking for possible routes
		for(int i = 0; i < map.length; i++){//Begin for
			for(int j = 0; j < map[i].length; j++){//Begin for
				if(map[i][j].type() != toCheck && (checkNeighbor(i-2, j, toCheck) || checkNeighbor(i+2, j, toCheck) || checkNeighbor(i, j-2, toCheck) || checkNeighbor(i, j+2, toCheck))){//Enters if there is a possible path to this block
					options.add(new Point(i, j));//Adds the option to list
				}//End if
			}//End for
		}//End for
		
		index = (int)(Math.random()*(options.size()/2)*2);//Gets the route to use
		
		switch((int)(Math.random()*4+1)){//Begin switch
		case 1://////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			try{//Begin try
				if(checkNeighbor(options.get(index).x()-2, options.get(index).y(), toCheck)){//Enters if valid movement
					map[options.get(index).x()-1][options.get(index).y()].setType((byte)(toCheck+pathCount));
					map[options.get(index).x()][options.get(index).y()].setType(toCheck);
					
					//These try-catch / ifs clear out other nearby paths
					try{//Begin try
						if(map[options.get(index).x()+2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()+1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()+2][options.get(index).y()].setType((byte)0);
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()][options.get(index).y()+2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()+1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()+2].setType((byte)0);			
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()][options.get(index).y()-2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()-1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()-2].setType((byte)0);				
						}//End if	
					}catch(Exception e){}//End try-catch

				}//End if
			}catch(Exception e){}//End try-catch
			break;//End case 1
		case 2://///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			try{//Begin try
				if(checkNeighbor(options.get(index).x()+2, options.get(index).y(), toCheck)){//Enters if there is a valid movement
					map[options.get(index).x()+1][options.get(index).y()].setType((byte)(toCheck+pathCount));
					map[options.get(index).x()][options.get(index).y()].setType(toCheck);
					
					//These try-catch / ifs clear out other nearby paths
					try{//Begin try
						if(map[options.get(index).x()-2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()-1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()-2][options.get(index).y()].setType((byte)0);
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()][options.get(index).y()+2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()+1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()+2].setType((byte)0);			
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()][options.get(index).y()-2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()-1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()-2].setType((byte)0);				
						}//End if
					}catch(Exception e){}//End try-catch
					
				}//End if
			}catch(Exception e){}//End try-catch
			break;//End case 2
		case 3://////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			try{//Begin try
				if(checkNeighbor(options.get(index).x(), options.get(index).y()-2, toCheck)){//Enters if there is a valid movement
					map[options.get(index).x()][options.get(index).y()-1].setType((byte)(toCheck+pathCount));
					map[options.get(index).x()][options.get(index).y()].setType(toCheck);
					
					//These try-catch / ifs clear out other nearby paths
					try{//End try
						if(map[options.get(index).x()][options.get(index).y()+2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()+1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()+2].setType((byte)0);
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()+2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()+1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()+2][options.get(index).y()].setType((byte)0);			
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()-2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()-1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()-2][options.get(index).y()].setType((byte)0);				
						}//End if
					}catch(Exception e){}//End try-catch
				}//End if
			}catch(Exception e){}//End try-catch
			break;//End case 3
		case 4:///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			try{
				if(checkNeighbor(options.get(index).x(), options.get(index).y()+2, toCheck)){//Enters if there is a valid movement
					map[options.get(index).x()][options.get(index).y()+1].setType((byte)(toCheck+pathCount));
					map[options.get(index).x()][options.get(index).y()].setType(toCheck);
					
					//These try-catch / ifs clear out other nearby paths
					try{//Begin try
						if(map[options.get(index).x()][options.get(index).y()-2].type() != toCheck){
							map[options.get(index).x()][options.get(index).y()-1].setType((byte)1);
							map[options.get(index).x()][options.get(index).y()-2].setType((byte)0);
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()+2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()+1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()+2][options.get(index).y()].setType((byte)0);			
						}//End if
					}catch(Exception e){}//End try-catch
					try{//Begin try
						if(map[options.get(index).x()-2][options.get(index).y()].type() != toCheck){
							map[options.get(index).x()-1][options.get(index).y()].setType((byte)1);
							map[options.get(index).x()-2][options.get(index).y()].setType((byte)0);				
						}//End if		
					}catch(Exception e){}//End try-catch
				}//End if
			}catch(Exception e){}//End try-catch
			break;//End case 4
		}//end switch statement
		
		options.clear();//Empties options
	}//End path method
	/*
	 checkNeighbor method
	 
	 checks whether the given block has a type that equals the check case
	 
	 Parameters: int i, int j, byte checkAgainst
	 Dependencies: none
	 
	 Cam Hatherell 
	 March 22 2018
	 */
	
	private boolean checkNeighbor(int i, int j, byte checkAgainst){//Begin checkNeighbor method
		try{//Begin try
			if(map[i][j].type() == checkAgainst){//Enters if the two types match
				return true;//Returns result
			}//End if
		}catch(Exception e){}//end try-catch
		return false;//unequal types
	}//end checkNeighbor method
	/*
	check method
	
	checks whether any of the fillable squares have been taken over by one single path | false if not
	 */
	private boolean check(){//Begin check method
		
		byte testAgainst = map[1][1].type();//value to check against | should be the same if all types are the same
		
		for(int i = 1; i < map.length; i+=2){//begin for | looks at all odd indices
			for(int j = 1; j < map[i].length; j+=2){//begin for | looks at all odd indices
				if(map[i][j].type() != testAgainst){//Begin if
					return false;//Ends as soon as a type does not match
				}//end if
			}//end for
		}//end for
		return true;//everything matched = true
	}//End check method
	/*
	 clearBlocks method
	 
	 Resets all blocks to their base state
	 
	 Parameters: None
	 Dependencies: none
	 
	 Cam Hatherell
	 March 22 2018
	 */
	private void clearBlocks(){//Begin clearBlocks method
		for(int i = 0; i < map.length; i++){//Begin for
			for(int j = 0; j < map[i].length; j++){//Begin for
			
				if((i/2)*2 != i && (j/2)*2 != j){//Enters for all uneven numbers
					map[i][j].setType((byte)1);//empty type 2
				}else{//otherwise
					map[i][j].setType((byte)0);//empty type 1
				}//end if
			}//end for
		}//end for
	}//end clearBlocks method
	/*
	 begin method
	 
	 Resets all the paths to start again with new path colours / speeds
	 */
	private void begin(){//begin begin method
		
		paths.clear();//clears old path data
		
		for(int i = 0; i < pathCount; i++){//Runs through the number of desired paths
			//Sets the map with the type
			map[(int)(Math.random()*80)*2+1]//Random number for row
					[(int)(Math.random()*45)*2+1]//Random number for col
							.setType((byte)(i + 2));//Sets the type to pathCount + taking into account the first 2 colour cases are empty (black)
			
			paths.add(new Type(pathCount));//Adds the new path to the list
		}
		
		paths.get((int)(Math.random() * paths.size())).setDelay((byte)0);//Speeds up / unbalances a random path to help ensure this action does not get stuck forever
	}//end begin method
}//end Map class