/*
 * ****************************************
 * Orb class
 * 
 * Action number 3 with recursion
 * 
 * Cam Hatherell
 * March 22 2018
 * ***************************************
 */
package main;

import java.awt.Color;
import java.util.ArrayList;

import hsa2.GraphicsConsole;

public class Orb {
	
	private boolean spawner;//Modifier for whether this orb will spawn more orbs
	
	private double x;//x value for the orb
	private double y;//y value for the orb
	
	private int radius;//size of the orb
	
	//Colour values for the orb
	private int R;
	private int G;
	private int B;
	
	//Motion values for the orb
	private double xVelocity;
	private double yVelocity;
	
	private double rot;//Rotation value of the orb
	
	private double rotMod = .2;//Rotational velocity of the orb
		
	ArrayList<Orb>orbs = new ArrayList<Orb>();//List of orbs spawned from this orb
	
	private Color colour;
	
	/*
	 Constructor
	 
	 Initializes everything
	 
	 Parameters: boolean spawner, int x, int y, double rot, int R, int G, int B
	 Dependencies: Math class
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Orb(boolean spawner, int x, int y, double rot, int R, int G, int B){//Begin Orb constructor
		//Sets all the following values to the ones passes through the caller
		this.x = x;
		this.y = y;
		this.rot = rot;
		this.spawner = spawner;
		
		this.R = R;
		this.G = G;
		this.B = B;
		
		colour = new Color(R,G,B);
		
		//Sets motion relative to the rotation of the spawner
		xVelocity = Math.cos(rot)*1.5;
		yVelocity = Math.sin(rot)*1.5;
		
		if(spawner){//Enters if this orb is a spawner
			radius = 10;//Makes it bigger if s0
		}else{//Otherwise
			radius = (int)(Math.random()*4);//Makes a smaller orb
		}//End if
		
	}//End orb constructor
	
	/*
	 doPhysics method
	 
	 Handles the physics of motion and spawning coming from the orbs | Returns false if the orb is meant to die
	 
	 Parameters: none
	 Dependencies: None
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public boolean doPhysics(){//Begin doPhysics method
		
		//Runs through all orbs spawned by this orb
		for(int i = 0; i < orbs.size(); i++){
			if(!orbs.get(i).doPhysics()){//Call to do their physics
				orbs.remove(i);//Removes them if needed
				i--;//Backs up the index to match the removal
			}//End if
		}//End for
		
		if(spawner){//Enters orb addition if this orb is a spawner
			rot += rotMod;//Adds the rotational velocity to rotation
			
			int growth = (int)(Math.random() * 50);//Splits chances for orb creation
			
			if(growth > 48){//3% chance a spawner is created
				orbs.add(new Orb(true, (int)(x + Math.cos(rot)*30), (int)(y + Math.sin(rot)*30), rot, R, G, B));
			}else{//80% chance a non-spawning orb is created
				orbs.add(new Orb(false, (int)(x + Math.cos(rot)*30), (int)(y + Math.sin(rot)*30), rot, R, G, B));
			}//end if
			
		}//End if
		
		//Applies motion
		x += xVelocity;
		y += yVelocity;
		
		int reduc = (int)(Math.random()*3);//Values to reduce colour of the orb
		
		boolean buffer = true;//Used at the end to check if the orb is dead | will remain true if so
		
		//The next chunk applies the reduction to all colour values
		
		if((R -= reduc) < 0){//Begin if
			R = 0;
		}else{//Begin else
			buffer = false;//Applies if R has colour
		}//End if
		if((G -= reduc) < 0){//Begin if
			G = 0;
		}else{//Begin else
			buffer = false;//Applies if G has colour
		}//End if
		if((B -= reduc) < 0){//Begin if
			B = 0;
		}else{//Begin else
			buffer = false;//Applies if B has colour
		}//End if
		
		colour = new Color(R, G, B);
		
		if(buffer){//Enters if there was no colour
			return false;//Returns the marking to kill the orb
		}//End if
		
		return true;//Marks the orb as still living
	}//End doPhysics method
	
	/*
	 stop method
	 
	 Allows a spawner to be stationary
	 
	 parameters: none
	 dependencies: none
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public void stop(){//Begin stop method
		//Sets motion values to 0
		xVelocity = 0;
		yVelocity = 0;
	}//End stop method
	
	/*
	 draw method
	 
	 Draws the orbs
	 
	 Parameters: GraphicsConsole gc
	 Dependencies: hsa2
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public void draw(GraphicsConsole gc){//Begin draw method
		//Runs through spawns and draws them first
		for(int i = 0; i < orbs.size(); i++){//Begin for
			orbs.get(i).draw(gc);//Calls method to draw spawn
		}//End for
		
		gc.setColor(colour);//Sets colour to that of this orb
		
		gc.fillOval((int)(x-radius), (int)y-radius, (int)radius*2, (int)radius*2);//Draws this orb

	}//End draw method
}//End Orb class
