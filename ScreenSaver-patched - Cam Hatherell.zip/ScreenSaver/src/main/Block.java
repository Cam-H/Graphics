/*
 * *******************************************
 * Block class
 * each instance of this class holds the component parts for the graphics component of the maze generator
 * 
 * Cam Hatherell
 * March 22 2018
 */
package main;

public class Block {//Begin block class
	
	private byte type;//Identifier for the type of block it is
	

	/*******Constructors**********/
	
	/*
	 Empty block constructor
	 
	 Sets the block to the base/empty value
	 
	 Parameters: None
	 Dependencies: None
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Block(){
		type = 0;
	}
	
	/*
	 Block Constructor with identifier
	 
	 Sets the block identifier to the given value
	 
	 Parameters: byte type
	 Dependencies: None
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Block(byte type){
		this.type = type;
	}

	/*******Getters**********/
	
	//Returns the identifier for this block
	public byte type(){//Begin type method
		return type;
	}//End type method

	/*******Setters**********/
	
	//Sets the identifier for this block
	public void setType(byte type){//Begin setType method
		this.type = type;
	}//End setType method

}//End block class
