package main;
/*
 * ***************************************************************
 * Screen Saver Assignment
 * 
 * Draws varying graphics to the screen with the goal of showing off what hsa2 and the students themselves are capable of
 * 
 * Cam Hatherell
 * March 22 2018
 * ***************************************************************
 */
import java.awt.Color;
import java.awt.Toolkit;

import hsa2.GraphicsConsole;

public class Main {//Begin main class
	public static void main(String[]args){//Begin main method
		new Main();//Initializes the program
	}//End main method
	
	//Graphics window where the screen save will be drawn; the window is full screen and undecorated
	private GraphicsConsole gc = new GraphicsConsole(true, (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight());
	
	//Meant to be used to hold the maze generator
	private Map map;//Effectively turned into the main loop due to changes in design part way through the project
	
	/*
	 Calls the initialization of the program
	 
	 Parameters: None
	 Dependencies: hsa2
	 
	 Cam Hatherell
	 March 22 2018
	 */
	private Main(){//Constructor
		initialize();//Calls the method to initialize the program
		
		while(true){//Loop to continue rendering the graphics 60 times per second
			
			drawGraphics();//Calls the method to draw the graphics
			
			//Stops the thread for 1000/60 milliseconds to meet the 60 FPS target
			try {//Begin try
				Thread.sleep(1000/60);
			} catch (InterruptedException e) {}//End try-catch
		}//End while loop
		
	}//End constructor method
	
	/*
	 Initializes the graphics window and the main looping object
	 
	 Parameters: None
	 Dependencies: hsa2
	 
	 Cam Hatherell
	 March 22 2018
	 */
	private void initialize(){//Begin initialize method
		
		//Basic setup for the graphics window
		gc.setAntiAlias(true);
		gc.setBackgroundColor(Color.BLACK);
		gc.enableMouseMotion(); // only needed for mouse (obviously)
		gc.clear();
		
		map = new Map();//Creates the main loop object
		map.start();//Starts the main loop
	}//End initialize method
	
	/*
	 Draws all graphics on the window so the user can see them
	 
	 Parameters: None
	 Dependencies: hsa2
	 
	 Cam Hatherell
	 March 22 2018
	 */
	private void drawGraphics(){//Begin drawGraphics method
		
		synchronized(gc){//Stops flickering by synchronizing actions
			
			gc.clear();//Clears the previous data on the screen
			
			map.draw(gc);//Exports the draw command to the main loop object to handle
		}//End synchronize
	}//End drawGraphics method
}//End main class