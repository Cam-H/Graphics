/*
 * ***********************************
 * Delay class
 * 
 * Holds a value to act as a delay allowing different paths of the maze generator to act at different speeds
 * 
 * Cam Hatherell
 * March 22 2018
 * ***********************************
 */
package main;

public class Delay {//Begin Delay class
	
	private byte baseDelay;//Holds the base delay that it takes each iteration
	
	private byte delay;//Holds the current delay before the next action
	
	/*
	 Constructor
	 
	 Sets the baseDelay to the given value
	 
	 Parameters: byte delay
	 Dependencies: none
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Delay(byte delay){//Begin Delay method
		baseDelay = delay;//Sets the delay
		
		reset();//Initializes the delay
	}//End Delay method
	
	
	//Getter for delay + it reduces delay allowing for counting to not need its own method call
	public byte delay(){//Begin delay method
		delay--;//Reduces the ongoing delay
		return delay;
	}//End delay method
	
	/**************Setters*****************/
	
	//Sets the delay to the base value
	public void reset(){//Begin reset method
		delay = baseDelay;
	}//End reset method
	public void setDelay(byte delay){//Begin setDelay method
		baseDelay = delay;
	}//End setDelay method

}//End Delay class
