/*
 * *******************************
 * Point class
 * 
 * Holds a point in a 2D system
 * 
 * Cam Hatherell
 * March 22 2018
 * *******************************
 */
package main;

public class Point {//Begin Point class
	
	private int x;//x value
	private int y;//y value
	
	/*
	 Constructor
	 
	 Sets the point to the received values
	 
	 Parameters: int x, int y
	 Dependencies: None
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Point(int x, int y) {//Begin point constructor
		this.x = x;
		this.y = y;
	}//End point constructor
	
	/*********Getters****************/
	
	//Returns the held x value
	public int x(){//Begin x method
		return x;
	}//End x method
	//Returns the hed y value
	public int y(){//Begin y method
		return y;
	}//End y method
}//End Point class
