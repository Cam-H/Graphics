/*
 * Smoke class
 * Holds the data for any given particle of the smoke effect
 * 
 * Cam Hatherell
 * March 22 2018
 */
package main;

import java.awt.Color;

import hsa2.GraphicsConsole;

public class Smoke {//Begin smoke class
	
	private int ID;//Identifier for draw method to vary shape
	
	private double x;//Holds the x value of the particle on the screen
	private int y;//Holds the y value of the particle on the screen
	
	private double width;//Holds the width of the particle
	private double height;//Holds the height of the particle

	private double yVelocity;//Holds the vertical velocity of the particl
	
	//Holds the red/green/blue values of the particle to give it colour
	private int R;
	private int G;
	private int B;
	
	private Color colour;
	
	/*
	 Smoke Constructor
	 Initializes the ID, x value and y value of the smoke particle
	 
	 Parameters : int ID, int x, int y
	 Dependencies: Math class
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Smoke(int ID, int x, int y){
		//Sets up the identifier
		this.ID = ID;
		
		//Sets up coordinates for on-screen drawing
		this.x = x;
		this.y = y;
		
		//Sets up the vertical movement of the particle
		yVelocity = (int)(Math.random()*-12);//Sets yVelocity
		width = (Math.random()*4);//Sets Width
		height = (Math.random()*4);//Sets Height
		
		R = 255;//R
		G = 255;//G
		B = (int)(Math.random()*230+25);//B
		
		colour = new Color(R,G,B);
	}
	
	/*
	 doPhysics method
	 
	 Handles the physics for the particle; returning true if the particle needs to be "killed"
	 
	 parameters: double windPower (currently not in use)
	 dependencies: Math class
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public boolean doPhysics(double windPower){//Begin doPhysics method

		x += windPower;//Adds wind value to x
		y += yVelocity;//Adds vertical motion to y
		
		//Increases particle size
		width += Math.random();
		height += Math.random();
				
		int reduc = (int)(Math.random()*3);//Gets reduction modifier for particle brightness
		
		boolean buffer = true;//Used at the end to check if the particle is dead | will remain true if so
		
		//The next chunk applies the reduction to all colour values
		
		if((R -= reduc) < 0){//Begin if
			R = 0;
		}else{//Begin else
			buffer = false;//Applies if R has colour
		}//End if
		if((G -= reduc) < 0){//Begin if
			G = 0;
		}else{//Begin else
			buffer = false;//Applies if G has colour
		}//End if
		if((B -= reduc) < 0){//Begin if
			B = 0;
		}else{//Begin else
			buffer = false;//Applies if B has colour
		}//End if
		
		colour = new Color(R,G,B);
		
		if(buffer){//Enters if there was no colour
			return false;//Returns the marking to kill the particle
		}//End if
		
		return true;//Marks the particle as still living
	}//End doPhysics method
	
	/*
	 draw method
	 
	 Draws the smoke particle onto the Graphics Console
	 
	 parameters: GraphicsConsole gc
	 Dependencies: hsa2
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public void draw(GraphicsConsole gc){//Begin draw method
		
		gc.setColor(colour);//Sets the color
		
		switch(ID){//Begin switch statement
		case 0://Star case
			gc.fillStar((int)(x-width/2), y-(int)height/2, (int)width, (int)height);
			break;//End star case
		case 1://Maple Leaf case
			gc.fillMapleLeaf((int)(x-width/2), y-(int)height/2, (int)width, (int)height);
			break;//End maple leaf case
		}
	}//End draw method
}//End Smoke class
