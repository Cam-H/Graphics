/*
 * ***************************************
 * Type Class
 * 
 * Holds the necessary data for any given path of the maze generator
 * 
 * Cam Hatherell
 * March 22 2018
 * *****************************************
 */
package main;

import java.awt.Color;

import hsa2.GraphicsConsole;

public class Type {//Begin Type class
	
	private Delay delay;//The delay for each action of this path
	
	//Red/Green/Blue colours for this path
	private int R;
	private int G;
	private int B;
	
	/*
	 Constructor
	 
	 Sets a random colour to the path and sets the delay base on the given input
	 
	 Parameter: byte pathCount
	 Dependencies: Math class
	 
	 Cam Hatherell
	 March 22 2018
	 */
	public Type(byte pathCount){//Begin Type method
		//Sets the colour
		R = (int)(Math.random()*255)+1;
		G = (int)(Math.random()*255)+1;
		B = (int)(Math.random()*255)+1;
		
		delay = new Delay((byte)(Math.random() * (pathCount*2) + 4));//Sets the delay
	}//End Type method
	
	/***************Getters******************/
	
	//Returns whether there is an ongoing delay | Resets the delay period if not
	public boolean delayed(){//Begin delayed method
		if(delay.delay() < 0){//Enters if there is no delay
			delay.reset();//Resets the delay
			return false;
		}//End if
		
		return true;
	}//End delayed method
	
	/***************Setters******************/
	
	//Sets the gc to the colour held by this path type
	public void setColor(GraphicsConsole gc){//Begin setColor method
		gc.setColor(new Color(R,G,B));//Sets the gc colour
	}//End setColor method
	
	//Changes the delay experienced by this path to the given byte value
	public void setDelay(byte delay){//Begin setDelay method
		this.delay.setDelay(delay);//Sets the new delay value
	}//End setDelay method
}//End Type class
