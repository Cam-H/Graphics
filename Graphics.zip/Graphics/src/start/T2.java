package start;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class T2 {
	public static void main(String[] args){
		int[][]map = new int[400][400];
		double transition = 0;
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map.length; j++){
				map[i][j] = 2;
			}
		}
		transition = Math.random()*390+1;
		int y = (int)transition;
		transition = Math.random()*390+1;
		int x = (int)transition;
		
		for(int i = 0; i < map.length*16; i++){
			transition = Math.random()*3+1;
			if((int)transition == 1){
				transition = Math.random()*400+1;
				for(int j = (int)transition; j < map.length; j++){
					transition = Math.random()*15+1;
					if((int)transition <= 1){
						j = 400;
					}else{
						try{
							map[i/16][j] = 1;
						}catch(ArrayIndexOutOfBoundsException e){}
					}
				}
			}else if((int)transition == 2){
				transition = Math.random()*400+1;
				for(int j = (int)transition; j < map.length; j++){
					transition = Math.random()*15+1;
					if((int)transition <= 1){
						j = 400;
					}else{
						try{
							map[j][i/16] = 1;
						}catch(ArrayIndexOutOfBoundsException e){}
					}
				}
			}else{}
		}
		
		
		JFrame frame = new JFrame("Testing");
		frame.setVisible(true);
		frame.setSize(800,800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new JPanel(){
			public void paint(Graphics g){
				for(int i = 0; i < map.length; i++){
					for(int j = 0; j < map.length; j++){
						if(map[i][j] == 2){
							g.fillRect(i*2, j*2, 2, 2);
						}
					}
				}
				g.setColor(Color.red);
				g.fillOval(x*2,y*2,20,20);
				
			}
		});
	}
}