package start;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class T1 {
	public static void main(String[] args){
		int[][]map = new int[400][400];
		double transition = 0;
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map.length; j++){
				map[i][j] = 2;
			}
		}
		transition = Math.random()*350+1;
		int y = (int)transition + 50;
		transition = Math.random()*350+1;
		int x = (int)transition + 50;
		int y2 = 0, x2 = 0, taken = 0;
		int count = 0;
		while(count < 300000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 != y && (y2 > 0)){
					y2--;
				}
				break;
			case 2:
				if(y2 != y && (y2 < 400)){
					y2++;
				}
				break;
			case 3:
				if(x2 != x && (x2 > 0)){
					x2--;
				}
				break;
			case 4:
				if(x2 != x && (x2 < 400)){
					x2++;
				}
				break;
			}
			map[y2][x2] = 1;
		}
		System.out.println("here");
		JFrame frame = new JFrame("Testing");
		frame.setVisible(true);
		frame.setSize(800,800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new JPanel(){
			public void paint(Graphics g){
				for(int i = 0; i < map.length; i++){
					for(int j = 0; j < map.length; j++){
						if(map[i][j] == 2){
							g.fillRect(i*2, j*2, 2, 2);
						}
					}
				}
				g.setColor(Color.red);
				g.fillOval(x,y,10,10);
				
			}
		});
	}
}
