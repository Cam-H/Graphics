package start;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class T4 {
	public static void main(String[] args){
		int[][]map = new int[1500][800];
		double transition = 0;
		int holder = 0;
		for(int i = 0; i < map.length; i++){
			for(int j = 0; j < map[i].length; j++){
				map[i][j] = 2;
			}
		}
		
		JFrame frame = new JFrame("Testing");
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setVisible(true);
		frame.setSize(1500,800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new JPanel(){
			public void paint(Graphics g){
				int cl = 0;
				double transition2 = 0;
				for(int z = 0; z < 10; z++){
					transition2 = Math.random()*255+1;
					cl = (int)transition2;
					g.setColor(new Color(cl,cl,cl));
					paintings(map,transition,holder);
					for(int i = 0; i < map.length; i++){
						for(int j = 0; j < map[i].length; j++){
							if(map[i][j] == 2){
								g.fillRect(i, j, 2, 2);
							}
						}
					}
				}
				for(int z = 0; z < 10; z++){
					transition2 = Math.random()*255+1;
					cl = (int)transition2;
					g.setColor(new Color(cl,cl,cl));
					paintings2(map,transition,holder);
					for(int i = 0; i < map.length; i++){
						for(int j = 0; j < map[i].length; j++){
							if(map[i][j] == 2){
								g.fillRect(i, j, 2, 2);
							}
						}
					}
				}
				for(int z = 0; z < 10; z++){
					transition2 = Math.random()*255+1;
					cl = (int)transition2;
					g.setColor(new Color(cl,cl,cl));
					paintings3(map,transition,holder);
					for(int i = 0; i < map.length; i++){
						for(int j = 0; j < map[i].length; j++){
							if(map[i][j] == 2){
								g.fillRect(i, j, 2, 2);
							}
						}
					}
				}
				for(int z = 0; z < 10; z++){
					transition2 = Math.random()*255+1;
					cl = (int)transition2;
					g.setColor(new Color(cl,cl,cl));
					paintings4(map,transition,holder);
					for(int i = 0; i < map.length; i++){
						for(int j = 0; j < map[i].length; j++){
							if(map[i][j] == 2){
								g.fillRect(i, j, 2, 2);
							}
						}
					}
				}
				for(int z = 0; z < 10; z++){
					transition2 = Math.random()*255+1;
					cl = (int)transition2;
					g.setColor(new Color(cl,cl,cl));
					paintings5(map,transition,holder);
					for(int i = 0; i < map.length; i++){
						for(int j = 0; j < map[i].length; j++){
							if(map[i][j] == 2){
								g.fillRect(i, j, 2, 2);
							}
						}
					}
				}
				
				
			}
		});
	}
	public static void paintings(int[][]map,double transition, int holder){
		int y2 = 0, x2 = 0, taken = 0;
		int count = 0;
		while(count < 200000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 > 0){
					y2--;
					map[y2][x2] = 1;
				}
				break;
			case 2:
				if(y2 < 1480){
					y2++;
					map[y2][x2] = 1;
				}
				break;
			case 3:
				if(x2 > 0){
					x2--;
					map[y2][x2] = 1;
				}
				break;
			case 4:
				if(x2 < 790){
					x2++;
					map[y2][x2] = 1;
				}
				break;
			}
			
		}
	}
	public static void paintings2(int[][]map,double transition, int holder){
		int y2 = 799, x2 = 799, taken = 0;
		int count = 0;
		while(count < 200000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 > 0){
					y2--;
					map[y2][x2] = 1;
				}
				break;
			case 2:
				if(y2 < 1480){
					y2++;
					map[y2][x2] = 1;
				}
				break;
			case 3:
				if(x2 > 0){
					x2--;
					map[y2][x2] = 1;
				}
				break;
			case 4:
				if(x2 < 790){
					x2++;
					map[y2][x2] = 1;
				}
				break;
			}
			
		}
	}
	public static void paintings3(int[][]map,double transition, int holder){
		int y2 = 0, x2 = 799, taken = 0;
		int count = 0;
		while(count < 50000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 > 0){
					y2--;
					map[y2][x2] = 1;
				}
				break;
			case 2:
				if(y2 < 1480){
					y2++;
					map[y2][x2] = 1;
				}
				break;
			case 3:
				if(x2 > 0){
					x2--;
					map[y2][x2] = 1;
				}
				break;
			case 4:
				if(x2 < 790){
					x2++;
					map[y2][x2] = 1;
				}
				break;
			}
			
		}
	}
	public static void paintings4(int[][]map,double transition, int holder){
		int y2 = 799, x2 = 0, taken = 0;
		int count = 0;
		while(count < 50000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 > 0){
					y2--;
					map[y2][x2] = 1;
				}
				break;
			case 2:
				if(y2 < 1480){
					y2++;
					map[y2][x2] = 1;
				}
				break;
			case 3:
				if(x2 > 0){
					x2--;
					map[y2][x2] = 1;
				}
				break;
			case 4:
				if(x2 < 790){
					x2++;
					map[y2][x2] = 1;
				}
				break;
			}
			
		}
	}
	public static void paintings5(int[][]map,double transition, int holder){
		int y2 = 400, x2 = 750, taken = 0;
		int count = 0;
		while(count < 50000){
			count++;
			transition = Math.random()*4+1;
			taken = (int)transition;
			
			 switch(taken){
			case 1:
				if(y2 > 0){
					y2--;
					map[y2][x2] = 1;
				}
				break;
			case 2:
				if(y2 < 1480){
					y2++;
					map[y2][x2] = 1;
				}
				break;
			case 3:
				if(x2 > 0){
					x2--;
					map[y2][x2] = 1;
				}
				break;
			case 4:
				if(x2 < 790){
					x2++;
					map[y2][x2] = 1;
				}
				break;
			}
			
		}
	}
}
